/*
 * reflabeler.h
 *
 *  Created on: Jun 3, 2014
 *      Author: chuzz
 */

#ifndef REFLABELER_H_
#define REFLABELER_H_

#include "utils.h"

// applica algoritmo di reference, su src, scrivi su dst
int reflabel(label_t dst[], bitimg_t src[]);

#endif /* REFLABELER_H_ */
