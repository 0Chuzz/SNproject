/*
 * mainLaptop.h
 *
 *  Created on: 12/set/2014
 *      Author: Alessandro
 */

#ifndef MAINLAPTOP_H_
#define MAINLAPTOP_H_

int mainLaptop(int argn, char *argv[]);

#endif /* MAINLAPTOP_H_ */
